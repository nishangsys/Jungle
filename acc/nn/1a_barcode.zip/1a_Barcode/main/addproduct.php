<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="saveproduct.php" method="post">
<div id="ac">
<span>Product Code : </span><br><input type="text" name="code" id="lform" /><br>
<span>Model : </span><br><input type="text" name="name" id="lform" /><br>
<span>Description : </span><br><textarea name="description" id="lform"></textarea><br>
<span>Unit : </span><br><input type="text" name="unit" id="lform" /><br>
<span>Cost : </span><br><input type="text" name="cost" id="lform" /><br>
<span>Price : </span><br><input type="text" name="price" id="lform" /><br>
<span>Qty : </span><br><input type="text" name="qty" id="lform" /><br>
<br><input id="btn" type="submit" value="save" />
</div>
</form>